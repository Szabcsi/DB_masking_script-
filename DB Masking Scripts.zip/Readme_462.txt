PFA onetime script for Masking data.
Steps to execute-
1.	Unzip and copy both files to UNIX/LINUX machine that can connect to oracle DB.
2.	Grant the script execution rights as follow:
chmod 775 MaskData*
3.	Then run MaskData_462.sh script as follow:
./MaskData_462.sh

(Please note the �./� it�s important.)
When prompt provide connect information (username/password/db name).
After running the script you will have a trace file in the working directory (Trace_MaskData_$datetime.txt).
For any questions , don�t hesitate to contact me.
