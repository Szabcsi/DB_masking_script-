#!/bin/ksh

# Name                  : MaskData_462.sh
#
# Parameters
# Input                 : Oracle User name,Connect string
# Output/Return         : None
# Purpose               :
# PS/CR No              : 
# Trace File Name       : Trace_MaskData_$datetime.txt in the current Directory
# To be executed as     : PAYplus user


if [ $# -gt 2  ]; then
  echo "Script expects two parameters. User, Connect-String (SID)."
fi

case $1 in
  '') echo "Please enter DB Owner Username: "
      read user;;
  *) user=$1;;
esac

case $2 in
  '') echo "Please enter Connect-String (SID): "
      read tns;;
  *) tns=$2;;
esac

echo "Please enter DB Password for $user: "
oldstate=`stty -g`
stty -echo
read pwd
stty $oldstate
echo "Running ....."
   
datetime=`date "+%Y-%m-%d_%H-%M-%S"`
filename="Trace_MaskData_$datetime.txt"

varexit=`sqlplus -S /nolog << sqlpluseof >> "$filename"

   CONN $user/$pwd@$tns
   SET SQLBLANK ON
   SET ECHO ON
   SET SERVEROUTPUT ON
   PROMPT "Executing Script for Masking Data"
   @MaskData_462.sql

   commit;

   EXIT;

sqlpluseof`

echo "Script Completed (exit code: $varexit)"
echo
echo "The log was written to '$filename'"
echo
